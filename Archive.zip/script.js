document.getElementById('languageSwitcher').addEventListener('change', function () {
    const selectedLang = this.value;

    // Collect all translatable elements
    const texts = Array.from(document.querySelectorAll('.translatable')).map(el => el.innerText);

    // Send the content to the PHP backend for translation
    fetch('translate.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ lang: selectedLang, content: texts })
    })
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                console.error('Translation Error:', data.error);
            } else {
                // Update page elements with the translated text
                const elements = document.querySelectorAll('.translatable');
                elements.forEach((el, index) => {
                    el.innerText = data[index].translations[0].text;
                });
            }
        })
        .catch(error => console.error('Fetch Error:', error));
});