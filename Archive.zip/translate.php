<?php
if (isset($_POST['lang']) && isset($_POST['content'])) {
    $lang = $_POST['lang'];  // 'twi' or 'en'
    $content = $_POST['content'];  // Array of content to translate

    // Azure API endpoint and key
    $apiKey = "26a0373407474f1cb3fa01f09a7f85e2";
    $url = "https://southafricanorth.api.cognitive.microsofttranslator.com/translate?api-version=3.0&to=$lang";

    // Prepare the data to send
    $data = [];
    foreach ($content as $text) {
        $data[] = ['Text' => $text];
    }

    // Prepare HTTP headers
    $headers = [
        "Content-Type: application/json",
        "Ocp-Apim-Subscription-Key: $apiKey",
        "Ocp-Apim-Subscription-Region: southafricanorth"  
    ];

    // Make the API request
    $options = [
        'http' => [
            'header' => implode("\r\n", $headers),
            'method' => 'POST',
            'content' => json_encode($data),
        ]
    ];

    $context = stream_context_create($options);
    $response = file_get_contents($url, false, $context);

    if ($response === FALSE) {
        echo json_encode(['error' => 'Translation failed.']);
        exit;
    }

    // Parse and return the response
    echo $response;
} else {
    echo json_encode(['error' => 'Invalid request.']);
}
?>